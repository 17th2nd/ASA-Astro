"""Codex C reasoning tests."""
